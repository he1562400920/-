package cn.itcast.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import cn.itcast.entity.Customer;
import cn.itcast.entity.User;
import cn.itcast.entity.Visit;
import cn.itcast.service.CustomerService;
import cn.itcast.service.UserService;
import cn.itcast.service.VisitService;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings("serial")
public class VisitAction extends ActionSupport implements ModelDriven<Visit> {
	
	private Visit visit = new Visit();
	public Visit getModel() {
		return visit;
	}
	
	private VisitService visitService;
	public void setVisitService(VisitService visitService) {
		this.visitService = visitService;
	}
	//客户注入
	private CustomerService customerService;
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}
	//用户注入
	private UserService userService;
	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	//1 到添加页面
	public String toAddPage() {
		//查询所有客户
		List<Customer> listCustomer = customerService.findAll();
		//查询所有用户
		 List<User> listUser =  userService.findAll();
		//放到request域
		 HttpServletRequest request =  ServletActionContext.getRequest();
		 request.setAttribute("listCustomer", listCustomer);
		 request.setAttribute("listUser", listUser);
		return "toAddPage";
	}
	//添加
	public String addVisit(){
		
		visitService.addvisit(visit);
		return "addVisit";
	}
	public String list(){
		
		List<Visit> listvistit = visitService.findall();
		ServletActionContext.getRequest().setAttribute("list", listvistit);
		return "list";
	}

}
