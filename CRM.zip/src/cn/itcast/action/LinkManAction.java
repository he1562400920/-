package cn.itcast.action;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import cn.itcast.entity.Customer;
import cn.itcast.entity.LinkMan;
import cn.itcast.service.CustomerService;
import cn.itcast.service.LinkManService;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@SuppressWarnings("serial")
public class LinkManAction extends ActionSupport implements ModelDriven<LinkMan>{
	
	private LinkMan linkMan = new LinkMan();
	public LinkMan getModel() {
		return linkMan;
	}
	//service注入
	private LinkManService linkManService;
	public void setLinkManService(LinkManService linkManService) {
		this.linkManService = linkManService;
	}
	//注入客户的service对象
	private CustomerService customerService;
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}

private File upload;
	
	//上传文件名称   表单里面文件上传项的name值FileName
	private String uploadFileName;
	
	//生成get和set方法
	public File getUpload() {
		return upload;
	}

	public void setUpload(File upload) {
		this.upload = upload;
	}

	public String getUploadFileName() {
		return uploadFileName;
	}

	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}
	//1 到添加页面
	public String toAddPage() {
		//获取所有客户放到域对象里
		List<Customer> listCustomer =  customerService.findAll();
		ServletActionContext.getRequest().setAttribute("listCustomer", listCustomer);
		return "toAddPage";
	}
	
	//添加联系人
	public String addLinkMan() throws Exception{
		if(upload != null) {
			//写上传代码
			//在服务器文件夹里面创建文件
			File serverFile = new File("F:\\sshp"+"/"+uploadFileName);
			//把上传文件复制到服务器文件里面
			FileUtils.copyFile(upload, serverFile);
		}
		linkManService.addLinkMan(linkMan);
		return "addLinkMan";
	}
	//联系人列表
	public String list(){
		List<LinkMan> list = linkManService.findAll();
		ServletActionContext.getRequest().setAttribute("list", list);
		return "list";
	}
	
	//到修改页面
	public String showLinkMan() {
		//使用模型驱动得到id值
		int linkid = linkMan.getLinkid();
		//根据id查询联系人对象
		LinkMan link = linkManService.findOne(linkid);
		
		//需要所有客户的list集合
		List<Customer> listCustomer = customerService.findAll();
		
		//放到域对象
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setAttribute("linkman", link);
		request.setAttribute("listCustomer", listCustomer);
		
		return "showLinkMan";
	}
	
	//修改
	public String updateLinkman(){
		
		linkManService.update(linkMan);
		return "updateLinkman";
	}
	//删除
	public String deletelink(){
		int lid = linkMan.getLinkid();
		LinkMan link = linkManService.findOne(lid);
		if(link != null){
			linkManService.delete(link);
		}
		return "deletelink";
	}
	//综合查询
	public String moreCondition(){
		 List<LinkMan> list =  linkManService.findCondition(linkMan);
		 ServletActionContext.getRequest().setAttribute("list", list);
		return "moreCondition";
	}
	public String toSelect(){
		List<Customer> list =  customerService.findAll();
		ServletActionContext.getRequest().setAttribute("list", list);
		return "toSelect";
	}

	

}
