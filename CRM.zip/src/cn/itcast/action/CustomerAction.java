package cn.itcast.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import cn.itcast.entity.Customer;
import cn.itcast.entity.Dict;
import cn.itcast.entity.PageBean;
import cn.itcast.service.CustomerService;

@SuppressWarnings("all")
public class CustomerAction extends ActionSupport implements ModelDriven<Customer> {
	
	private Dict dict ;
	public void setDict(Dict dict) {
		this.dict = dict;
	}

	private Customer customer = new Customer();
	public Customer getModel() {
		// 模型驱动
		return customer;
	}
	
	private CustomerService customerService;
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}
	
	//根据级别统计
	public String countLevel() {
		List list = customerService.findCountLevel();
		ServletActionContext.getRequest().setAttribute("list", list);
		return "countLevel";
	}
	
	//根据来源统计
	public String countSource() {
		List list = customerService.findCountSource();
		ServletActionContext.getRequest().setAttribute("list", list);
		return "countSource";
	}
	
	//属性封装当前页
	private Integer currentPage;
	public Integer getCurrentPage() {
		return currentPage;
	}public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}
   //分页方法
	 public String listpage(){
		 //调用customerService方法封装数据
		PageBean pageBean =  customerService.listpage(currentPage);
		//把pageBean放到域对象里
		ServletActionContext.getRequest().setAttribute("pageBean", pageBean);
		return "listpage";
	}
	 //条件查询
	 public String listcondition(){
		 //若有用户名则根据用户名查询，无则查询全部
		if(customer.getCustName()!=null&&!"".equals(customer.getCustName())){
			List<Customer> list =  customerService.listCondiction(customer);
			ServletActionContext.getRequest().setAttribute("list", list);
		}else{
			list = customerService.findAll();
		}
		 
		 return "listcondition";
	 }
	
	//1 到添加页面
	public String toAddPage() {
		List<Dict> listDict = customerService.findAllDictLevel();
		ServletActionContext.getRequest().setAttribute("listDict", listDict);
		return "toAddPage";
	}
	
	//2 添加的方法
	public String add() {
		//添加逻辑
		customerService.add(customer);
		return "add";
	}
	
	private List<Customer> list;
	//生成变量的get方法
	public List<Customer> getList() {
		return list;
	}
	//3 客户列表的方法
	public String list() {
		list = customerService.findAll();
		return "list";
	}


	//4 修改和删除的方法
	public String delete() {
		int cid = customer.getCid();
		Customer c = customerService.findone(cid);
		if(c != null){
			customerService.delete(c);
		}
		return "delete";
	}
	//到列表页面
	public String showcustomer() {
		int cid = customer.getCid();
		Customer cc = customerService.findone(cid);
		ServletActionContext.getRequest().setAttribute("customer", cc);
		return "showcustomer";
	}
	//更新
	public String update() {
		customerService.update(customer);
		return "update";
	}
	
	//到综合查询页面
	public String toSelectCustomer(){
		
		return "toSelectCustomer";
	}
	//综合查询
	public String moreCondition(){
	 	List<Customer> list =  customerService.findbyCondition(customer);
	 	ServletActionContext.getRequest().setAttribute("list", list);
		return "moreCondition";
	}
}




