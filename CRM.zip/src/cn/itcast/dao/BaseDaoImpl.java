package cn.itcast.dao;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

public class BaseDaoImpl<T> extends HibernateDaoSupport implements BaseDao<T> {
	
	private Class pClass;
	//得到Class对象例如Customer
	//构造方法
	@SuppressWarnings("all")
	public BaseDaoImpl(){
		//第一步 得到当前运行类Class
		Class classzz = getClass();
//		System.out.println("****************"+classzz);
		//第二步 得到运行类的 父类的参数化类型 BaseDaoImpl<Customer>
		// Type getGenericSuperclass()  
		Type type  = classzz.getGenericSuperclass();
		// 使用Type子接口 ParameterizedType
		ParameterizedType Ptype = (ParameterizedType) type;
//		System.out.println("***********"+Ptype);
		//第三步 得到实际类型参数<Customer>里面Customer
		//Type[] getActualTypeArguments() 
		Type[] types = Ptype.getActualTypeArguments();
		Class tclass = (Class) types[0];
//		System.out.println("*****"+tclass);
		this.pClass = tclass;
		
	} 
	@SuppressWarnings("all")
	public List<T> findAll() {
		return (List<T>) this.getHibernateTemplate().find("from "+pClass.getSimpleName());
	}
	@SuppressWarnings("all")
	public T findOne(int id) {
		return (T) this.getHibernateTemplate().get(pClass, id);
	}
	
	public void add(T t) {
		this.getHibernateTemplate().save(t);
	}

	public void delete(T t) {
		this.getHibernateTemplate().delete(t);
	}

	public void update(T t) {
		this.getHibernateTemplate().update(t);
	}

}
