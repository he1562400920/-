package cn.itcast.dao;

import java.util.List;

import cn.itcast.entity.LinkMan;

public interface LinkManDao {

	List<LinkMan> findall();


	void add(LinkMan linkMan);


	LinkMan finone(Integer linkid);


	void update(LinkMan linkMan);


	void delete(LinkMan link);


	List<LinkMan> findcondition(LinkMan linkMan);

}
