package cn.itcast.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import cn.itcast.entity.LinkMan;

public class LinkManDaoImpl extends HibernateDaoSupport implements LinkManDao{

	//查全部
	@SuppressWarnings("all")
	public List<LinkMan> findall() {
		return (List<LinkMan>) this.getHibernateTemplate().find("from LinkMan");
	}

	//添加联系人
	public void add(LinkMan linkMan) {
		this.getHibernateTemplate().save(linkMan);
	}

	//查单个
	public LinkMan finone(Integer linkid) {
		
		return this.getHibernateTemplate().get(LinkMan.class,linkid);
	}

	public void update(LinkMan linkMan) {
		// 修改
		this.getHibernateTemplate().update(linkMan);
	}

	public void delete(LinkMan link) {
		// 删除
		this.getHibernateTemplate().delete(link);
		
	}

	//综合联系人查询
	@SuppressWarnings("all")
	public List<LinkMan> findcondition(LinkMan linkMan) {
		DetachedCriteria criteria = DetachedCriteria.forClass(LinkMan.class);
		if(linkMan.getLkmName()!=null&&!"".equals(linkMan.getLkmName())){
			criteria.add(Restrictions.eq("lkmName", linkMan.getLkmName()));
		}if(linkMan.getCustomer().getCid()!=0&&linkMan.getCustomer().getCid()>0){
			criteria.add(Restrictions.eq("customer.cid", linkMan.getCustomer().getCid()));
		}
		
		return (List<LinkMan>) this.getHibernateTemplate().findByCriteria(criteria);
	}

}
