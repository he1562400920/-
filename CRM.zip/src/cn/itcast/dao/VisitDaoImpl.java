package cn.itcast.dao;

import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import cn.itcast.entity.Visit;


public class VisitDaoImpl extends HibernateDaoSupport implements VisitDao {

	//添加
	public void addvisit(Visit visit) {
		this.getHibernateTemplate().save(visit);
	}

	//列表
	public List<Visit> findall() {
		return (List<Visit>) this.getHibernateTemplate().find("from Visit");
	}

	
}
