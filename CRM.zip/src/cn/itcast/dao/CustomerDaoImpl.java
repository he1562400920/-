package cn.itcast.dao;

import java.util.HashMap;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;

import cn.itcast.entity.Customer;
import cn.itcast.entity.Dict;

public class CustomerDaoImpl extends BaseDaoImpl<Customer> implements CustomerDao {

//	添加客户功能
//	public void add(Customer customer) {
//		this.getHibernateTemplate().save(customer);
//	}

	//查找全部
//	@SuppressWarnings("all")
//	public List<Customer> findAll() {
//		return (List<Customer>) this.getHibernateTemplate().find("from Customer");
//	}

//	public Customer findOne(int cid) {
//		return this.getHibernateTemplate().get(Customer.class, cid);
//	}

//	public void delete(Customer c) {
//		this.getHibernateTemplate().delete(c);
//	}
//
//	public void update(Customer customer) {
//		this.getHibernateTemplate().update(customer);
//	}
    //查找全部记录数
	@SuppressWarnings("all")
	public int findCount() {
		List<Object> list =  (List<Object>) this.getHibernateTemplate().find("select count(*) from Customer");
		if(list!=null&&list.size()!=0){
			Object obj = list.get(0);
			//变成int类型 先换lang然后int
			Long lobj = (Long) obj;
			int count = lobj.intValue();
			return count;
		}
		return 0;
	}
	//分页
	@SuppressWarnings("all")
	public List<Customer> findPage(int begin, int pageSize) {
		// 1 底层实现（了解）
		//得到SessionFactory
//		SessionFactory sessionFactory = this.getHibernateTemplate().getSessionFactory();
		//得到Session对象
//		Session session = sessionFactory.getCurrentSession();
		//设置分页信息
//		Query query =  session.createQuery("from Customer");
//		query.setFirstResult(begin);
//		query.setMaxResults(pageSize);
//		List<Customer> list = query.list();
		
		//2 离线对象和HibernateTemplate模板实现
		DetachedCriteria criteria = DetachedCriteria.forClass(Customer.class);
		//调用HibernateTemplate模板
		//第一个参数是离线对象
		//第二个对象是开始位置
		//第三个参数是每页记录数
		List<Customer> list =  (List<Customer>) this.getHibernateTemplate().findByCriteria(criteria, begin, pageSize);
		
		return list;
	}

	@SuppressWarnings("all")
	public List<Customer> listCondiction(Customer customer) {
		// TODO Auto-generated method stub
		//调用hibernateTemplate模板
//		List<Customer> list =  (List<Customer>) this.getHibernateTemplate().
//		    find("from Customer where   custName like ?", "%"+customer.getCustName()+"%");
		//第三种方式
		// 1 创建离线对象，设置对哪个实体类进行操作
		DetachedCriteria criteria = DetachedCriteria.forClass(Customer.class);
		// 2 设置对实体类哪个属性
		criteria.add(Restrictions.like("custName", "%"+customer.getCustName()+"%"));
		
		// 3 调用hibernateTemplate里面的方法得到list集合
		List<Customer> list = 
				(List<Customer>) this.getHibernateTemplate().findByCriteria(criteria);
		return list;
	}
//	@SuppressWarnings("all")
//	public List<Customer> findCondition(Customer customer) {
//		//使用hibernate模板里面find方法实现
//		String hql = "from Customer where 1=1 ";
//		//创建list集合，如果值不为空，把值设置到list里面
//		List<Object> p = new ArrayList<Object>();
//		//判断条件值是否为空，如果不为空拼接hql语句\
//		if(customer.getCustName()!=null&& !"".equals(customer.getCustName())){
//			//拼接hql
//			hql+=" and custName=?";
//			p.add(customer.getCustName());
//		}if(customer.getCustLevel()!=null&&!"".equals(customer.getCustLevel())){
//			hql+=" and custLevel=?";
//			p.add(customer.getCustLevel());
//		}if(customer.getCustSource()!=null&&!"".equals(customer.getCustSource())){
//			hql+=" and custSource=?";
//			p.add(customer.getCustSource());
//		}
//		System.out.println("***********"+hql);
//		System.out.println("***********"+p);
//		return (List<Customer>) this.getHibernateTemplate().find(hql, p.toArray());
//	}
	@SuppressWarnings("all")
	public List<Customer> findCondition(Customer customer) {
		DetachedCriteria criteria = DetachedCriteria.forClass(Customer.class);
		if(customer.getCustName()!=null&& !"".equals(customer.getCustName())){
			criteria.add(Restrictions.eq("custName", customer.getCustName()));
		}if(customer.getDictCustLevel().getDname()!=null&&!"".equals(customer.getDictCustLevel().getDname())){
			criteria.add(Restrictions.eq("dictCustLevel.dname", customer.getDictCustLevel().getDname()));
		}if(customer.getCustSource()!=null&&!"".equals(customer.getCustSource())){
			criteria.add(Restrictions.eq("custSource", customer.getCustSource()));
		}
		return (List<Customer>) this.getHibernateTemplate().findByCriteria(criteria);
	}
	@SuppressWarnings("all")
	public List<Dict> findAllDictLevel() {
		// TODO Auto-generated method stub
		 return (List<Dict>) this.getHibernateTemplate().find("from Dict");
	}

	//客户来源统计
	public List findCountSource() {
		// 因为写复杂语句，建议直接调用底层sql实现
		// SQLQuery对象
		//1 得到session对象
//		this.getHibernateTemplate().getSessionFactory();
		Session session = this.getSessionFactory().getCurrentSession();
		//2 创建SQLQuery对象
		SQLQuery sqlQuery = session.createSQLQuery("SELECT COUNT(*) AS num,custSource FROM hy_customer GROUP BY custSource");
		
		//放到实体类对象里面，没有对应的实体类
//		sqlQuery.addEntity(实体类class);
		
		/*
		 * 因为返回值有两个字段，一个字段是id，一个是名称，
		 * 所以把返回数据转换map结构
		 * */
		sqlQuery.setResultTransformer(Transformers.aliasToBean(HashMap.class));
		
		//调用方法得到结果
		//返回list，默认每部分是数组形式
		List list = sqlQuery.list();
		
		return list;
	}

	//根据客户级别统计
	public List findCountLevel() {
		//获取session对象
		Session session = this.getSessionFactory().getCurrentSession();
		//创建SQLQuery对象
		SQLQuery sqlQuery = session.createSQLQuery("SELECT c.num,d.dname FROM (SELECT COUNT(*) AS num,custLevel FROM hy_customer GROUP BY custLevel) c , t_dict d WHERE c.custLevel=d.did");
		//得到结果
		//转换map结构
		sqlQuery.setResultTransformer(Transformers.aliasToBean(HashMap.class));
		List list = sqlQuery.list();
		return list;
	}
	

}
