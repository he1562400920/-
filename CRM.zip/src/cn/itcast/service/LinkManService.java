package cn.itcast.service;


import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import cn.itcast.dao.LinkManDao;
import cn.itcast.entity.LinkMan;

@Transactional
public class LinkManService {
	private LinkManDao linkManDao;

	public void setLinkManDao(LinkManDao linkManDao) {
		this.linkManDao = linkManDao;
	}

	public List<LinkMan> findAll() {
		// TODO Auto-generated method stub
		return linkManDao.findall();
	}

	public void addLinkMan(LinkMan linkMan) {
		// TODO Auto-generated method stub
		 linkManDao.add(linkMan);
	}

	public LinkMan findOne(Integer linkid) {
		// TODO Auto-generated method stub
		return linkManDao.finone(linkid);
	}

	public void update(LinkMan linkMan) {
		// TODO Auto-generated method stub
		linkManDao.update(linkMan);
	}

	public void delete(LinkMan link) {
		// TODO Auto-generated method stub
		linkManDao.delete(link);
	}

	public List<LinkMan> findCondition(LinkMan linkMan) {
		// TODO Auto-generated method stub
		return linkManDao.findcondition(linkMan);
	}
	
	
	
	
	
}
