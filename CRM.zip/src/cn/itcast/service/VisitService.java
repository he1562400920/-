package cn.itcast.service;



import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import cn.itcast.dao.VisitDao;
import cn.itcast.entity.Visit;

@Transactional
public class VisitService {

	private VisitDao visitDao;

	public void setVisitDao(VisitDao visitDao) {
		this.visitDao = visitDao;
	}

	//添加
	public void addvisit(Visit visit) {
		visitDao.addvisit(visit);
	}

	public List<Visit> findall() {
		// TODO Auto-generated method stub
		return visitDao.findall();
	}
	
	
	
}
